import React,{Component} from 'react';
import Welcome from './Welcome';
import Employee from './Employee';
import Updatestate from './Updatestate';
import Emp from './Emp';
import App2 from './App2';
class App1 extends React.Component{
  constructor(){
    super();
    this.state={EmployeeID:123,Ename:"Swati"}
  }
  render()
  {
    return (
      <div>
      <h1>Hello</h1>
      <App2/>
      <Updatestate/>
      <Emp/>

      <h1>{this.state.EmployeeID}</h1>
      <Welcome/>
      <Welcome name="Swati"/>
      <Welcome name="Manisha"/>
      <hr/>
      <Employee/>
      </div>
    );
  }
}

export default App1;