import React from "react";



function Welcome(props){
  return (
    <div>
      <h1>Hello React !!!</h1>
      <h3>hi {props.name}</h3>
    </div>
  );
}
Welcome.defaultProps={name:"Guest"}
export default Welcome;

