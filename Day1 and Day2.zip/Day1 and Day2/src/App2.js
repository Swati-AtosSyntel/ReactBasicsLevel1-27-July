import React,{Component} from 'react';

class App2 extends React.Component{
  constructor(){
    super();
    this.state={message:"Welcome to React...."}
    this.updateMessgae=this.updateMessgae.bind(this);
  }
  updateMessgae(){
    this.setState({message:"React is a javascript library to build component based UI.."})

  }
  render()
  {
    return (
      <div>
        <Child msg={this.state.message} updateMessageProp={this.updateMessgae}>

        </Child>
        <h4>{this.state.message}</h4>
      </div>
    );
  }
}
class Child extends React.Component{
  render(){
    return(
      <div>
        <button onClick={this.props.updateMessageProp}>Updaet State of App2</button>
        <h4>{this.props.msg}</h4>
      </div>
    )
  }
}
export default App2;