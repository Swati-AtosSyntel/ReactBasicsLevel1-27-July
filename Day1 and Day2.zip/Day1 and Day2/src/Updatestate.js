import React,{Component} from 'react';

class Updatestate extends React.Component{
  constructor(){
    super();
    this.state={num:0}
    this.setnewNumber=this.setNewNum.bind(this);
    
  }
  setNewNum(){
    this.setState({num:this.state.num+2})
  }
  render()
  {
    return (
      <div>
        <button onClick={this.setnewNumber}>Increment Number</button>
        <Content newNum={this.state.num}/>
      </div>
    );
  }
}
class Content extends React.Component{
  componentWillMount(){
    console.log('Component Will Mount')
  }
  componentDidMount(){
    console.log('Component Did Mount')
  }
  componentWillReceiveProps(newProps){
    console.log('Component will receive props')

  }
  shouldComponentUpdate(newProps,newState){
    return true;
  }
  componentWillUpdate(nextProps,nextState){
    console.log('Component will update')
  }
  render(){
    return(
      <div>
        <p>{this.props.newNum}</p>
      </div>
    )
  }
}
export default Updatestate;