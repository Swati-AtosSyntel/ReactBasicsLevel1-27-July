import React,{Component} from 'react';
import Welcome from './Welcome';
class Employee extends React.Component{
  constructor(){
    super();
    this.state={EmpID:111,Ename:"Swati"}
    
  }
  render()
  {
    return (
      <div>
      <h1>Hello</h1>
      <h1>{this.state.EmployeeID}</h1>
      <h1>{this.state.Ename}</h1>
      <Tablerow id={this.state.EmpID} name={this.state.Ename}/>
      </div>
    );
  }
}
class Tablerow extends React.Component{
  render(){
    return(
      <table border="1">
        <tr>
          <th>Employee ID</th>
          <th>Employee Name</th>
        </tr>
        <tr>
          <td>{this.props.id}</td>
          <td>{this.props.name}</td>
        </tr>
      </table>
    )
  }
}
export default Employee;