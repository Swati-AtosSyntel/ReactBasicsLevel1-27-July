import React,{Component} from 'react';

class Emp extends React.Component{
 
  render()
  {
      const numbers=[1,2,3,4];
      const doubledList=numbers.map((num)=> <li>{num*3}</li>)
      console.log(doubledList)
    return (

        <ul>
     {doubledList}
     </ul>
    );
  }
}

export default Emp;